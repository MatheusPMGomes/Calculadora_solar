package com.example.pwon_calculadora_solar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
