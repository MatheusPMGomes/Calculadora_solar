import 'package:flutter/material.dart';

import 'app_widget.dart';

main(){
  runApp(AppWidget());
}